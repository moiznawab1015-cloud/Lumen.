"use client";
import { useState } from "react"; import { useRouter } from "next/navigation";
import Logo from "@/components/Logo"; import { supabase } from "@/lib/supabase/client";
const slides = [
  { h: "Share what lights you up", p: "Photos and short videos from the people and places you care about." },
  { h: "Make Reels in minutes", p: "Record, trim, add music and pick a look, all in one place." },
  { h: "Find your people", p: "Follow creators, join conversations and keep your account as private as you like." }];
export default function Welcome() {
  const r = useRouter(); const [i, setI] = useState(0); const [mode, setMode] = useState<"intro" | "signup" | "login">("intro");
  const [f, setF] = useState({ email: "", password: "", username: "", full_name: "" }); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (mode === "signup" && !/^[a-z0-9_.]{3,30}$/.test(f.username.toLowerCase())) return setErr("Usernames use 3–30 letters, numbers, dots or underscores.");
    if (f.password.length < 8) return setErr("Use a password with at least 8 characters.");
    setBusy(true); const db = supabase();
    const { data, error } = mode === "signup"
      ? await db.auth.signUp({ email: f.email, password: f.password, options: { data: { username: f.username.toLowerCase(), full_name: f.full_name } } })
      : await db.auth.signInWithPassword({ email: f.email, password: f.password });
    setBusy(false);
    if (error) return setErr(/database error/i.test(error.message) ? "That username is taken. Try another." : error.message);
    if (mode === "signup" && !data.session) return setErr("Check your email to confirm your account, then log in.");
    r.replace("/"); r.refresh();
  }
  if (mode === "intro") return <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-between p-8">
    <Logo size={48} />
    <section key={i} aria-live="polite"><h1 className="font-display text-5xl font-extrabold leading-[1.02] tracking-tight">{slides[i].h}</h1>
      <p className="mt-4 text-lg text-mute">{slides[i].p}</p></section>
    <div className="space-y-5"><div className="flex gap-2" aria-hidden>{slides.map((_, n) => <span key={n} className={`h-1.5 rounded-full transition-all ${n === i ? "w-8 bg-glow" : "w-1.5 bg-line"}`} />)}</div>
      {i < slides.length - 1 ? <div className="flex gap-3"><button className="btn-glow flex-1" onClick={() => setI(i + 1)}>Next</button><button className="btn-ghost" onClick={() => setI(slides.length - 1)}>Skip</button></div>
        : <div className="flex gap-3"><button className="btn-glow flex-1" onClick={() => setMode("signup")}>Create account</button><button className="btn-ghost" onClick={() => setMode("login")}>Log in</button></div>}</div></main>;
  return <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-center gap-6 p-8">
    <Logo /><h1 className="font-display text-4xl font-extrabold tracking-tight">{mode === "signup" ? "Create your account" : "Welcome back"}</h1>
    <form onSubmit={submit} className="space-y-3" noValidate>
      {mode === "signup" && <><input className="field" placeholder="Full name" value={f.full_name} onChange={set("full_name")} autoComplete="name" />
        <input className="field" placeholder="Username" value={f.username} onChange={set("username")} autoCapitalize="none" autoComplete="username" required /></>}
      <input className="field" type="email" placeholder="Email" value={f.email} onChange={set("email")} autoComplete="email" required />
      <input className="field" type="password" placeholder="Password (8+ characters)" value={f.password} onChange={set("password")} autoComplete={mode === "signup" ? "new-password" : "current-password"} required />
      {err && <p role="alert" className="text-sm text-red-500">{err}</p>}
      <button className="btn-glow w-full" disabled={busy}>{busy ? "One moment…" : mode === "signup" ? "Create account" : "Log in"}</button></form>
    <button className="text-sm text-mute" onClick={() => { setErr(""); setMode(mode === "signup" ? "login" : "signup"); }}>
      {mode === "signup" ? "Already have an account? Log in" : "New here? Create an account"}</button></main>;
}
