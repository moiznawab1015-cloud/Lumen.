import Link from "next/link"; import { notFound, redirect } from "next/navigation"; import { createClient } from "@/lib/supabase/server"; import Logo from "@/components/Logo";
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const db = await createClient(); const { data: { user } } = await db.auth.getUser(); if (!user) redirect("/welcome");
  const { data: me } = await db.from("profiles").select("role").eq("id", user.id).single(); if (me?.role !== "admin") notFound();
  return <div className="mx-auto min-h-dvh max-w-5xl p-4 sm:p-8"><header className="mb-6 flex items-center gap-3"><Logo size={32} /><span className="font-display text-2xl font-extrabold">Lumen admin</span><Link href="/" className="btn-ghost ml-auto">Back to app</Link></header>{children}</div>;
}
