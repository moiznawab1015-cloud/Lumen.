import Link from "next/link"; import { createClient } from "@/lib/supabase/server"; import { ago } from "@/lib/time"; import RequestActions from "@/components/RequestActions"; import LiveRefresh from "@/components/LiveRefresh";
const TEXT: Record<string, string> = { like: "liked your post", comment: "commented on your post", reply: "replied to your comment", follow: "started following you", mention: "mentioned you", message: "sent you a message" };
export default async function Notifications() {
  const db = await createClient(); const { data: { user } } = await db.auth.getUser(); const me = user!.id;
  const [{ data: list }, { data: reqs }] = await Promise.all([
    db.from("notifications").select("*, actor:profiles!actor_id(username,avatar_url)").eq("recipient_id", me).order("created_at", { ascending: false }).limit(50),
    db.from("follows").select("follower_id, follower:profiles!follower_id(username,avatar_url)").eq("followee_id", me).eq("status", "pending")]);
  await db.from("notifications").update({ read: true }).eq("recipient_id", me).eq("read", false);
  const av = (u: any) => <span className="h-11 w-11 shrink-0 overflow-hidden rounded-full bg-line">{u?.avatar_url && <img src={u.avatar_url} alt="" className="h-full w-full object-cover" />}</span>;
  return <main><LiveRefresh me={me} /><h1 className="px-4 pb-3 pt-6 font-display text-3xl font-extrabold">Notifications</h1>
    {(reqs ?? []).length > 0 && <section className="border-b border-line px-4 pb-3"><h2 className="mb-2 text-sm font-semibold">Follow requests</h2><ul className="space-y-2">{reqs!.map((r: any) => <li key={r.follower_id} className="flex items-center gap-3">{av(r.follower)}<Link href={`/u/${r.follower.username}`} className="text-sm font-semibold">{r.follower.username}</Link><RequestActions follower={r.follower_id} me={me} /></li>)}</ul></section>}
    {!list?.length ? <p className="px-8 py-16 text-center text-mute">Nothing yet. Likes, comments, follows and mentions show up here.</p>
      : <ul>{list.map((n: any) => <li key={n.id}><Link href={n.post_id ? `/p/${n.post_id}` : n.kind === "message" ? "/messages" : `/u/${n.actor.username}`} className={`flex items-center gap-3 px-4 py-3 ${n.read ? "" : "bg-glow/10"}`}>
        {av(n.actor)}<p className="flex-1 text-sm"><span className="font-semibold">{n.actor.username}</span> {TEXT[n.kind]} <span className="text-mute">{ago(n.created_at)}</span></p></Link></li>)}</ul>}</main>;
}
