import { redirect } from "next/navigation"; import { createClient } from "@/lib/supabase/server"; import BottomNav from "@/components/BottomNav"; import SignOutButton from "@/components/SignOutButton";
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const db = await createClient(); const { data: { user } } = await db.auth.getUser(); if (!user) redirect("/welcome");
  const { data: me } = await db.from("profiles").select("username,banned,suspended_until").eq("id", user.id).single();
  const susp = me?.suspended_until && new Date(me.suspended_until) > new Date();
  if (me?.banned || susp) return <main className="mx-auto flex min-h-dvh max-w-md flex-col items-start justify-center gap-4 p-8"><h1 className="font-display text-3xl font-extrabold">{me.banned ? "Your account is banned" : "Your account is suspended"}</h1>
    <p className="text-mute">{me.banned ? "This account broke our community rules and can no longer be used." : `You can use Lumen again after ${new Date(me.suspended_until!).toLocaleDateString()}.`}</p><SignOutButton /></main>;
  return <div className="mx-auto min-h-dvh max-w-md pb-24">{children}<BottomNav username={me?.username ?? ""} /></div>;
}
