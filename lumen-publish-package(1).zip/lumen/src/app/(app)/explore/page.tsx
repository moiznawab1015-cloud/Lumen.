import Link from "next/link"; import { Search } from "lucide-react"; import { createClient } from "@/lib/supabase/server"; import Grid from "@/components/Grid"; import FollowButton from "@/components/FollowButton";
const COLS = "id,thumb_url,media_url,is_reel";
export default async function Explore({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams; const db = await createClient(); const { data: { user } } = await db.auth.getUser(); const me = user!.id;
  const term = q.trim().replace(/[%,()*]/g, " ").slice(0, 50); const { data: bl } = await db.from("blocks").select("blocked_id").eq("blocker_id", me); const blocked = new Set((bl ?? []).map(b => b.blocked_id));
  const box = <form action="/explore" className="relative px-4 pb-3 pt-6"><Search size={18} className="absolute left-7 top-[2.15rem] text-mute" /><input name="q" defaultValue={q} placeholder="Search people, posts, #tags" className="field !pl-10" aria-label="Search" /></form>;
  if (term) {
    let users: any[] = [], posts: any[] = [];
    if (term.startsWith("#")) { const { data: h } = await db.from("hashtags").select("id").eq("tag", term.slice(1).toLowerCase()).maybeSingle();
      if (h) { const { data: pt } = await db.from("post_hashtags").select("post_id").eq("hashtag_id", h.id).limit(60);
        if (pt?.length) posts = (await db.from("posts").select(COLS).in("id", pt.map(x => x.post_id)).eq("removed", false).order("created_at", { ascending: false })).data ?? []; } }
    else { [users, posts] = await Promise.all([
      db.from("profiles").select("id,username,full_name,avatar_url").or(`username.ilike.%${term}%,full_name.ilike.%${term}%`).limit(15).then(r => (r.data ?? []).filter(u => !blocked.has(u.id))),
      db.from("posts").select(COLS).ilike("caption", `%${term}%`).eq("removed", false).order("created_at", { ascending: false }).limit(30).then(r => r.data ?? [])]); }
    return <main>{box}{users.length > 0 && <ul className="px-4 pb-3">{users.map(u => <li key={u.id}><Link href={`/u/${u.username}`} className="flex items-center gap-3 py-2"><span className="h-11 w-11 overflow-hidden rounded-full bg-line">{u.avatar_url && <img src={u.avatar_url} alt="" className="h-full w-full object-cover" />}</span>
      <span><span className="block text-sm font-semibold">{u.username}</span><span className="block text-xs text-mute">{u.full_name}</span></span></Link></li>)}</ul>}
      {posts.length > 0 && <Grid items={posts} />}{!users.length && !posts.length && <p className="px-8 py-16 text-center text-mute">No results for “{term}”. Try a different word or a #hashtag.</p>}</main>;
  }
  const [tags, reels, photos, f, top, likes] = await Promise.all([
    db.from("trending_tags").select("tag,uses").order("uses", { ascending: false }).limit(10).then(r => r.data ?? []),
    db.from("trending_posts").select(COLS).eq("is_reel", true).order("score", { ascending: false }).limit(10).then(r => r.data ?? []),
    db.from("trending_posts").select(COLS).eq("kind", "photo").order("score", { ascending: false }).limit(12).then(r => r.data ?? []),
    db.from("follows").select("followee_id").eq("follower_id", me).then(r => new Set((r.data ?? []).map(x => x.followee_id))),
    db.from("profile_stats").select("user_id").order("followers", { ascending: false }).limit(40).then(r => r.data ?? []),
    db.from("likes").select("post_id").eq("user_id", me).order("created_at", { ascending: false }).limit(50).then(r => r.data ?? [])]);
  const sug = top.map(t => t.user_id).filter(id => id !== me && !f.has(id) && !blocked.has(id)).slice(0, 6);
  const creators = sug.length ? ((await db.from("profiles").select("id,username,full_name,avatar_url,is_private").in("id", sug)).data ?? []).sort((a, b) => sug.indexOf(a.id) - sug.indexOf(b.id)) : [];
  let picked: any[] = [];
  if (likes.length) { const { data: tg } = await db.from("post_hashtags").select("hashtag_id").in("post_id", likes.map(l => l.post_id)); const hids = [...new Set((tg ?? []).map(t => t.hashtag_id))];
    if (hids.length) { const { data: pp } = await db.from("post_hashtags").select("post_id").in("hashtag_id", hids).limit(80); const liked = new Set(likes.map(l => l.post_id)); const pids = [...new Set((pp ?? []).map(x => x.post_id))].filter(i => !liked.has(i));
      if (pids.length) picked = (await db.from("posts").select(COLS).in("id", pids).eq("removed", false).neq("author_id", me).limit(12)).data ?? []; } }
  const h2 = (t: string) => <h2 className="px-4 pb-2 pt-5 font-display text-xl font-extrabold">{t}</h2>;
  return <main>{box}
    {tags.length > 0 && <><ul className="flex gap-2 overflow-x-auto px-4">{tags.map(t => <li key={t.tag} className="shrink-0"><Link href={`/explore?q=${encodeURIComponent("#" + t.tag)}`} className="btn-ghost !py-1.5">#{t.tag} <span className="ml-1 text-mute">{t.uses}</span></Link></li>)}</ul></>}
    {picked.length > 0 && <>{h2("Picked for you")}<Grid items={picked} /></>}
    {reels.length > 0 && <>{h2("Trending Reels")}<ul className="flex gap-2 overflow-x-auto px-4">{reels.map(r => <li key={r.id} className="w-32 shrink-0"><Link href={`/p/${r.id}`}><img src={r.thumb_url ?? r.media_url} alt="" className="aspect-[9/16] w-full rounded-xl2 bg-line object-cover" loading="lazy" /></Link></li>)}</ul></>}
    {creators.length > 0 && <>{h2("Creators to follow")}<ul className="space-y-1 px-4">{creators.map(c => <li key={c.id} className="flex items-center gap-3 py-1.5"><Link href={`/u/${c.username}`} className="flex flex-1 items-center gap-3"><span className="h-11 w-11 overflow-hidden rounded-full bg-line">{c.avatar_url && <img src={c.avatar_url} alt="" className="h-full w-full object-cover" />}</span>
      <span><span className="block text-sm font-semibold">{c.username}</span><span className="block text-xs text-mute">{c.full_name}</span></span></Link><FollowButton me={me} target={c.id} initial="none" isPrivate={c.is_private} /></li>)}</ul></>}
    {photos.length > 0 && <>{h2("Popular photos")}<Grid items={photos} /></>}
    {!reels.length && !photos.length && !creators.length && <p className="px-8 py-16 text-center text-mute">Nothing to discover yet. Be the first to post.</p>}</main>;
}
