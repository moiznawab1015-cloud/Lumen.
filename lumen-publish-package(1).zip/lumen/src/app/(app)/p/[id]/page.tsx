import { notFound } from "next/navigation"; import { createClient } from "@/lib/supabase/server"; import { enrich } from "@/lib/feed"; import PostCard from "@/components/PostCard"; import CommentThread from "@/components/CommentThread";
export default async function PostPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const db = await createClient(); const { data: { user } } = await db.auth.getUser();
  const { data: p } = await db.from("posts").select("*, profiles(username,avatar_url)").eq("id", id).maybeSingle(); if (!p) notFound();
  const [c] = await enrich(db, [p], user!.id);
  return <main><PostCard me={user!.id} {...c} /><CommentThread postId={id} me={user!.id} /></main>;
}
