import Link from "next/link"; import { createClient } from "@/lib/supabase/server"; import { enrich } from "@/lib/feed"; import Reels from "@/components/Reels";
export default async function ReelsPage() {
  const db = await createClient(); const { data: { user } } = await db.auth.getUser(); const me = user!.id;
  const { data: posts } = await db.from("posts").select("*, profiles(username,avatar_url)").eq("is_reel", true).eq("removed", false).order("created_at", { ascending: false }).limit(25);
  if (!posts?.length) return <main className="p-10 text-center text-mute"><p>No Reels yet.</p><Link href="/studio" className="btn-glow mt-4">Make the first one</Link></main>;
  const cards = await enrich(db, posts, me); const { data: f } = await db.from("follows").select("followee_id,status").eq("follower_id", me).in("followee_id", [...new Set(posts.map(p => p.author_id))]);
  const st = new Map((f ?? []).map(x => [x.followee_id, x.status]));
  return <Reels me={me} items={cards.map(c => ({ ...c, following: st.get(c.post.author_id) ?? "none" }))} />;
}
