import Link from "next/link"; import { createClient } from "@/lib/supabase/server"; import { loadConversations } from "@/lib/dm"; import { ago } from "@/lib/time"; import NewChat from "@/components/NewChat";
export default async function Messages() {
  const db = await createClient(); const { data: { user } } = await db.auth.getUser(); const convs = await loadConversations(db, user!.id);
  return <main><h1 className="px-4 pb-3 pt-6 font-display text-3xl font-extrabold">Messages</h1><NewChat />
    {convs.length === 0 ? <p className="px-8 py-12 text-center text-mute">No conversations yet. Enter a username above or tap Message on a profile.</p>
      : <ul>{convs.map(c => <li key={c.id}><Link href={`/messages/${c.id}`} className="flex items-center gap-3 px-4 py-3">
        <span className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-line">{c.other?.avatar_url && <img src={c.other.avatar_url} alt="" className="h-full w-full object-cover" />}</span>
        <span className="min-w-0 flex-1"><span className={`block text-sm ${c.unread ? "font-bold" : "font-semibold"}`}>{c.other?.username}</span>
          <span className={`block truncate text-sm ${c.unread ? "text-ink" : "text-mute"}`}>{c.last ? (c.last.body ?? (c.last.image_url ? "Sent a photo" : "Shared a post")) : "No messages yet"}</span></span>
        <span className="flex flex-col items-end gap-1 text-xs text-mute">{c.last && ago(c.last.created_at)}{c.unread > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-glow px-1 font-bold text-glow-ink">{c.unread}</span>}</span></Link></li>)}</ul>}</main>;
}
