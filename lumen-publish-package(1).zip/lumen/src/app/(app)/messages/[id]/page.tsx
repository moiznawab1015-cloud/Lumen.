import Link from "next/link"; import { notFound } from "next/navigation"; import { ChevronLeft } from "lucide-react"; import { createClient } from "@/lib/supabase/server"; import ChatView from "@/components/ChatView";
export default async function Chat({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const db = await createClient(); const { data: { user } } = await db.auth.getUser();
  const { data: o } = await db.from("conversation_members").select("profiles(username,avatar_url)").eq("conversation_id", id).neq("user_id", user!.id).maybeSingle(); if (!o) notFound();
  const { data: msgs } = await db.from("messages").select("*, shared:posts(id,thumb_url,media_url,caption)").eq("conversation_id", id).order("created_at"); const p = o.profiles as any;
  return <main><header className="sticky top-0 z-10 flex items-center gap-3 border-b border-line bg-bg/90 px-3 py-3 backdrop-blur"><Link href="/messages" aria-label="Back"><ChevronLeft /></Link>
    <span className="h-8 w-8 overflow-hidden rounded-full bg-line">{p.avatar_url && <img src={p.avatar_url} alt="" className="h-full w-full object-cover" />}</span><Link href={`/u/${p.username}`} className="font-semibold">{p.username}</Link></header>
    <ChatView me={user!.id} convId={id} initial={msgs ?? []} /></main>;
}
