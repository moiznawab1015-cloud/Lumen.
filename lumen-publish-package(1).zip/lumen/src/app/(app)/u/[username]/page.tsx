import Link from "next/link"; import { notFound } from "next/navigation"; import { Lock } from "lucide-react";
import { createClient } from "@/lib/supabase/server"; import FollowButton from "@/components/FollowButton"; import ProfileActions from "@/components/ProfileActions";
export default async function Profile({ params, searchParams }: { params: Promise<{ username: string }>; searchParams: Promise<{ tab?: string }> }) {
  const { username } = await params; const { tab = "posts" } = await searchParams;
  const db = await createClient(); const { data: { user } } = await db.auth.getUser();
  const { data: p } = await db.from("profiles").select("*").eq("username", username).single(); if (!p) notFound();
  const own = user?.id === p.id;
  const { data: bl } = user && !own ? await db.from("blocks").select("blocked_id").match({ blocker_id: user.id, blocked_id: p.id }).maybeSingle() : { data: null };
  const [{ data: s }, { data: rel }] = await Promise.all([
    db.from("profile_stats").select("*").eq("user_id", p.id).single(),
    user && !own ? db.from("follows").select("status").match({ follower_id: user.id, followee_id: p.id }).maybeSingle() : Promise.resolve({ data: null })]);
  let items: { id: string; thumb_url: string | null; media_url: string; kind: string }[] = [];
  if (tab === "saved" && own) { const { data } = await db.from("saves").select("posts(id,thumb_url,media_url,kind)").eq("user_id", p.id).order("created_at", { ascending: false }); items = (data ?? []).flatMap((r: any) => r.posts ? [r.posts] : []); }
  else { const { data } = await db.from("posts").select("id,thumb_url,media_url,kind").eq("author_id", p.id).eq("is_reel", tab === "reels").order("created_at", { ascending: false }); items = data ?? []; }
  const locked = p.is_private && !own && rel?.status !== "accepted";
  const stat = (n: number | null, l: string) => <div className="text-center"><div className="font-display text-xl font-extrabold">{n ?? 0}</div><div className="text-xs text-mute">{l}</div></div>;
  const tabs = ["posts", "reels", ...(own ? ["saved"] : [])];
  return <main className="px-5 pt-8">
    <header className="flex items-center gap-5"><div className="h-24 w-24 shrink-0 overflow-hidden rounded-full border-2 border-glow bg-line">{p.avatar_url && <img src={p.avatar_url} alt="" className="h-full w-full object-cover" />}</div>
      <div className="flex flex-1 justify-around">{stat(s?.posts, "Posts")}{stat(s?.followers, "Followers")}{stat(s?.following, "Following")}</div></header>
    <div className="mt-4"><h1 className="font-display text-xl font-extrabold">{p.full_name || p.username}</h1><p className="text-sm text-mute">@{p.username}</p>
      {p.bio && <p className="mt-2 text-sm">{p.bio}</p>}{p.website && <a href={p.website} rel="noopener nofollow" className="text-sm font-semibold text-glow">{p.website.replace(/^https?:\/\//, "")}</a>}
      <p className="mt-2 text-xs text-mute">{s?.likes_received ?? 0} likes received</p></div>
    <div className="mt-4">{own ? <Link href="/settings/profile" className="btn-ghost w-full">Edit profile</Link>
      : user && <FollowButton me={user.id} target={p.id} initial={(rel?.status as any) ?? "none"} isPrivate={p.is_private} />}</div>
    {!own && user && <ProfileActions me={user.id} target={p.id} username={p.username} blocked={!!bl} />}
    <nav className="mt-6 flex border-b border-line">{tabs.map(t => <Link key={t} href={`?tab=${t}`} className={`flex-1 pb-3 text-center text-sm font-semibold capitalize ${tab === t ? "border-b-2 border-glow" : "text-mute"}`}>{t}</Link>)}</nav>
    {locked ? <p className="mt-12 flex flex-col items-center gap-2 text-center text-mute"><Lock />This account is private. Follow to see their posts.</p>
      : items.length === 0 ? <p className="mt-12 text-center text-mute">{own ? "Nothing here yet. Tap + to share your first moment." : "No posts yet."}</p>
      : <ul className="mt-1 grid grid-cols-3 gap-0.5">{items.map(i => <li key={i.id} className="aspect-square overflow-hidden bg-line">
          <img src={i.thumb_url ?? i.media_url} alt="" className="h-full w-full object-cover" loading="lazy" /></li>)}</ul>}</main>;
}
