"use client";
import { useState } from "react"; import Link from "next/link"; import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
function probe(file: File): Promise<{ duration: number; thumb: Blob | null }> {
  return new Promise(res => { const v = document.createElement("video"); v.muted = true; v.playsInline = true; v.preload = "auto"; v.src = URL.createObjectURL(file); let d = 0;
    v.onloadedmetadata = () => { d = v.duration; v.currentTime = Math.min(0.1, d / 2); };
    v.onseeked = () => { const c = document.createElement("canvas"); c.width = 480; c.height = Math.round(480 * v.videoHeight / v.videoWidth) || 640; c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height); c.toBlob(b => res({ duration: d, thumb: b }), "image/jpeg", 0.8); };
    v.onerror = () => res({ duration: 0, thumb: null }); });
}
export default function Create() {
  const r = useRouter(); const [file, setFile] = useState<File | null>(null); const [url, setUrl] = useState(""); const [caption, setCaption] = useState(""); const [reel, setReel] = useState(false);
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false); const isVideo = file?.type.startsWith("video");
  function pick(e: React.ChangeEvent<HTMLInputElement>) { const f = e.target.files?.[0]; setErr(""); if (!f) return;
    if (!/^(image|video)\//.test(f.type)) return setErr("Choose a photo or video."); if (f.size > 200e6) return setErr("Files must be under 200 MB.");
    setFile(f); setUrl(URL.createObjectURL(f)); setReel(f.type.startsWith("video")); }
  async function publish() {
    if (!file) return; setBusy(true); setErr(""); const db = supabase(); const { data: { user } } = await db.auth.getUser(); const me = user!.id;
    try {
      let duration: number | null = null, thumb: Blob | null = null;
      if (isVideo) { ({ duration, thumb } = await probe(file)); if (!duration) throw new Error("We couldn't read that video."); if (duration > 60) throw new Error("Videos can be 60 seconds at most."); }
      const key = `${me}/${Date.now()}`; const up = await db.storage.from("media").upload(key, file, { contentType: file.type }); if (up.error) throw up.error;
      let thumb_url: string | null = null; if (thumb) { await db.storage.from("media").upload(`${key}-thumb`, thumb, { contentType: "image/jpeg" }); thumb_url = db.storage.from("media").getPublicUrl(`${key}-thumb`).data.publicUrl; }
      const { data: post, error } = await db.from("posts").insert({ author_id: me, kind: isVideo ? "video" : "photo", is_reel: !!(isVideo && reel), media_url: db.storage.from("media").getPublicUrl(key).data.publicUrl, thumb_url, duration_s: duration, caption: caption.trim() || null }).select("id").single();
      if (error) throw error;
      const tags = [...new Set((caption.match(/#([\p{L}\p{N}_]{1,40})/gu) ?? []).map(t => t.slice(1).toLowerCase()))];
      if (tags.length) { const { data: hs } = await db.from("hashtags").upsert(tags.map(tag => ({ tag })), { onConflict: "tag" }).select("id");
        if (hs?.length) await db.from("post_hashtags").insert(hs.map(h => ({ post_id: post.id, hashtag_id: h.id }))); }
      r.replace("/"); r.refresh();
    } catch (e: any) { setErr(e?.message?.length < 80 ? e.message : "Couldn't publish. Check your connection and try again."); setBusy(false); }
  }
  return <main className="space-y-4 p-6"><h1 className="font-display text-3xl font-extrabold">New post</h1>
    <Link href="/studio" className="btn-ghost w-full">Open Reel studio: record, trim, filters, music</Link>
    {url ? (isVideo ? <video src={url} controls playsInline className="max-h-[50dvh] w-full rounded-xl2 bg-line" /> : <img src={url} alt="Preview" className="max-h-[50dvh] w-full rounded-xl2 object-contain" />)
      : <label className="grid h-56 cursor-pointer place-items-center rounded-xl2 border-2 border-dashed border-line text-center text-mute">Tap to choose a photo or video<input type="file" accept="image/*,video/*" hidden onChange={pick} /></label>}
    {file && <><textarea className="field" rows={3} maxLength={2200} placeholder="Write a caption. Use #hashtags and @mentions." value={caption} onChange={e => setCaption(e.target.value)} />
      {isVideo && <label className="flex items-center justify-between rounded-xl2 border border-line bg-surface px-4 py-3 text-sm">Share as a Reel<input type="checkbox" checked={reel} onChange={e => setReel(e.target.checked)} className="h-5 w-5 accent-[#FFB020]" /></label>}</>}
    {err && <p role="alert" className="text-sm text-red-500">{err}</p>}
    <button className="btn-glow w-full" disabled={!file || busy} onClick={publish}>{busy ? "Publishing…" : "Publish"}</button></main>;
}
