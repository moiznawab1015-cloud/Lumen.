"use client";
import { useEffect, useRef, useState } from "react"; import { useRouter } from "next/navigation"; import { Circle, Square, Play, Pause, Upload, Music } from "lucide-react";
import { supabase } from "@/lib/supabase/client"; import { PRESETS, cssFilter, ffmpegFilter } from "@/lib/filters"; import { exportReel } from "@/lib/export"; import { saveTags } from "@/lib/tags";
const readDur = (url: string) => new Promise<number>(res => { const v = document.createElement("video"); v.preload = "metadata"; v.src = url; v.onloadedmetadata = () => res(v.duration); v.onerror = () => res(0); });
export default function Studio() {
  const r = useRouter(); const [file, setFile] = useState<File | null>(null); const [url, setUrl] = useState(""); const [dur, setDur] = useState(0); const [start, setStart] = useState(0); const [end, setEnd] = useState(0);
  const [pi, setPi] = useState(0); const [adj, setAdj] = useState({ b: 1, c: 1, s: 1 }); const [vol, setVol] = useState(1); const [music, setMusic] = useState<File | null>(null); const [mUrl, setMUrl] = useState(""); const [mVol, setMVol] = useState(0.6);
  const [caption, setCaption] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(""); const [prog, setProg] = useState(0); const [playing, setPlaying] = useState(false);
  const [cam, setCam] = useState(false); const [recording, setRec] = useState(false); const [sec, setSec] = useState(0);
  const vRef = useRef<HTMLVideoElement>(null), aRef = useRef<HTMLAudioElement>(null), camRef = useRef<HTMLVideoElement>(null), stream = useRef<MediaStream | null>(null), mr = useRef<MediaRecorder | null>(null), timer = useRef<any>(null);
  const filter = cssFilter(PRESETS[pi], adj);
  useEffect(() => { if (cam && camRef.current && stream.current) camRef.current.srcObject = stream.current; }, [cam]);
  useEffect(() => { if (vRef.current) vRef.current.volume = vol; }, [vol, url]); useEffect(() => { if (aRef.current) aRef.current.volume = mVol; }, [mVol, mUrl]);
  useEffect(() => () => { stream.current?.getTracks().forEach(t => t.stop()); clearInterval(timer.current); }, []);
  async function load(f: File, known?: number) {
    setErr(""); if (f.size > 150e6) return setErr("Choose a video under 150 MB."); const u = URL.createObjectURL(f); let d = await readDur(u); if (!isFinite(d) || !d) d = known ?? 0;
    if (!d) return setErr("We couldn't read that video."); setFile(f); setUrl(u); setDur(d); setStart(0); setEnd(Math.min(d, 60));
  }
  async function openCam() { try { stream.current = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 1280 } }, audio: true }); setCam(true); }
    catch { setErr("Camera access was blocked. Allow it in your browser settings, or upload a video."); } }
  function startRec() { const mime = MediaRecorder.isTypeSupported("video/mp4") ? "video/mp4" : "video/webm"; const chunks: Blob[] = []; const m = new MediaRecorder(stream.current!, { mimeType: mime }); mr.current = m;
    m.ondataavailable = e => e.data.size && chunks.push(e.data); let n = 0;
    m.onstop = () => { clearInterval(timer.current); stream.current?.getTracks().forEach(t => t.stop()); setCam(false); setRec(false); load(new File(chunks, `rec.${mime === "video/mp4" ? "mp4" : "webm"}`, { type: mime }), Math.max(n, 1)); };
    m.start(); setRec(true); setSec(0); timer.current = setInterval(() => { n++; setSec(n); if (n >= 60) m.stop(); }, 1000); }
  function toggle() { const v = vRef.current!, a = aRef.current; if (v.paused) { if (v.currentTime < start || v.currentTime >= end) v.currentTime = start; v.play(); a?.play().catch(() => {}); setPlaying(true); } else { v.pause(); a?.pause(); setPlaying(false); } }
  function tick() { const v = vRef.current!; if (v.currentTime >= end) { v.currentTime = start; if (aRef.current) aRef.current.currentTime = 0; } }
  async function publish() {
    if (!file) return; setErr(""); setProg(0);
    try { const d = end - start; if (d < 1) throw new Error("Pick at least 1 second."); if (d > 60) throw new Error("Reels can be 60 seconds at most.");
      setBusy("Rendering your Reel…"); const out = await exportReel({ file, start, dur: d, vf: ffmpegFilter(PRESETS[pi], adj), vol, music, musicVol: mVol, onProgress: setProg });
      setBusy("Uploading…"); const db = supabase(); const { data: { user } } = await db.auth.getUser(); const me = user!.id, key = `${me}/${Date.now()}`;
      const u1 = await db.storage.from("media").upload(`${key}.mp4`, out.video, { contentType: "video/mp4" }); if (u1.error) throw u1.error;
      await db.storage.from("media").upload(`${key}-thumb.jpg`, out.thumb, { contentType: "image/jpeg" });
      const pub = (p: string) => db.storage.from("media").getPublicUrl(p).data.publicUrl;
      const { data: post, error } = await db.from("posts").insert({ author_id: me, kind: "video", is_reel: true, media_url: pub(`${key}.mp4`), thumb_url: pub(`${key}-thumb.jpg`), duration_s: d, filter_preset: PRESETS[pi].name, trim_start: start, trim_end: end, audio_volume: vol, caption: caption.trim() || null }).select("id").single();
      if (error) throw error; await saveTags(db, post.id, caption); r.replace("/reels"); r.refresh();
    } catch (e: any) { setErr(e?.message && e.message.length < 80 ? e.message : "Couldn't render this video. Try a shorter clip or a different file."); setBusy(""); }
  }
  const range = (l: string, v: number, set: (n: number) => void, min = 0.5, max = 1.5) => <label className="flex items-center gap-3 text-sm"><span className="w-24">{l}</span><input type="range" min={min} max={max} step={0.05} value={v} onChange={e => set(+e.target.value)} className="flex-1 accent-[#FFB020]" /></label>;
  if (!file) return <main className="space-y-4 p-6"><h1 className="font-display text-3xl font-extrabold">Reel studio</h1>
    {cam ? <div className="space-y-3"><video ref={camRef} autoPlay muted playsInline className="aspect-[9/16] max-h-[60dvh] w-full rounded-xl2 bg-black object-cover" />
      <button className="btn-glow w-full gap-2" onClick={recording ? () => mr.current?.stop() : startRec}>{recording ? <><Square size={16} />Stop · {sec}s / 60s</> : <><Circle size={16} />Start recording</>}</button></div>
      : <div className="grid gap-3"><button className="btn-glow gap-2 py-4" onClick={openCam}><Circle size={18} />Record with camera</button>
        <label className="btn-ghost cursor-pointer gap-2 py-4"><Upload size={18} />Upload from gallery<input type="file" accept="video/*" hidden onChange={e => e.target.files?.[0] && load(e.target.files[0])} /></label></div>}
    {err && <p role="alert" className="text-sm text-red-500">{err}</p>}</main>;
  return <main className="space-y-4 p-4 pb-28"><h1 className="font-display text-2xl font-extrabold">Edit your Reel</h1>
    <div className="relative mx-auto aspect-[9/16] max-h-[52dvh] overflow-hidden rounded-xl2 bg-black"><video ref={vRef} src={url} playsInline onTimeUpdate={tick} onLoadedMetadata={() => { vRef.current!.currentTime = start; }} style={{ filter }} className="h-full w-full object-contain" />
      {mUrl && <audio ref={aRef} src={mUrl} loop />}
      <button onClick={toggle} aria-label={playing ? "Pause" : "Play"} className="absolute inset-0 grid place-items-center text-white/90">{!playing && <Play size={56} />}{playing && <Pause size={0} />}</button></div>
    <ul className="flex gap-3 overflow-x-auto py-1">{PRESETS.map((p, i) => <li key={p.name} className="shrink-0 text-center"><button onClick={() => setPi(i)} aria-pressed={i === pi} className={`block rounded-xl p-0.5 ${i === pi ? "ring-2 ring-glow" : ""}`}>
      <span className="block h-14 w-14 rounded-lg" style={{ background: "linear-gradient(135deg,#ff6b6b,#4dabf7 55%,#ffd43b)", filter: cssFilter(p, { b: 1, c: 1, s: 1 }) }} /></button><span className="text-xs">{p.name}</span></li>)}</ul>
    <div className="space-y-2 rounded-xl2 border border-line bg-surface p-4">{range("Brightness", adj.b, v => setAdj({ ...adj, b: v }))}{range("Contrast", adj.c, v => setAdj({ ...adj, c: v }))}{range("Saturation", adj.s, v => setAdj({ ...adj, s: v }), 0, 2)}</div>
    <div className="space-y-2 rounded-xl2 border border-line bg-surface p-4"><p className="text-sm font-semibold">Trim · {(end - start).toFixed(1)}s</p>
      <label className="flex items-center gap-3 text-sm"><span className="w-24">Start</span><input type="range" min={0} max={dur} step={0.1} value={start} onChange={e => { const v = +e.target.value; if (v < end - 1) { setStart(v); if (vRef.current) vRef.current.currentTime = v; } }} className="flex-1 accent-[#FFB020]" /></label>
      <label className="flex items-center gap-3 text-sm"><span className="w-24">End</span><input type="range" min={0} max={dur} step={0.1} value={end} onChange={e => { const v = +e.target.value; if (v > start + 1 && v - start <= 60) setEnd(v); }} className="flex-1 accent-[#FFB020]" /></label></div>
    <div className="space-y-2 rounded-xl2 border border-line bg-surface p-4">{range("Video volume", vol, setVol, 0, 1)}
      <label className="btn-ghost w-full cursor-pointer gap-2"><Music size={16} />{music ? music.name.slice(0, 24) : "Add music or audio"}<input type="file" accept="audio/*" hidden onChange={e => { const f = e.target.files?.[0]; if (f) { setMusic(f); setMUrl(URL.createObjectURL(f)); } }} /></label>
      {music && range("Music volume", mVol, setMVol, 0, 1)}</div>
    <textarea className="field" rows={2} maxLength={2200} placeholder="Write a caption. Use #hashtags and @mentions." value={caption} onChange={e => setCaption(e.target.value)} />
    {err && <p role="alert" className="text-sm text-red-500">{err}</p>}
    <button className="btn-glow w-full" disabled={!!busy} onClick={publish}>{busy ? `${busy} ${busy.startsWith("Render") ? Math.round(prog * 100) + "%" : ""}` : "Publish Reel"}</button>
    <button className="btn-ghost w-full" disabled={!!busy} onClick={() => { setFile(null); setUrl(""); }}>Start over</button></main>;
}
