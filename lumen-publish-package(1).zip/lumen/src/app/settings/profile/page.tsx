"use client";
import { useEffect, useState } from "react"; import { useRouter } from "next/navigation"; import Link from "next/link"; import { supabase } from "@/lib/supabase/client";
export default function EditProfile() {
  const r = useRouter(); const db = supabase(); const [p, setP] = useState<any>(null); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { db.auth.getUser().then(async ({ data: { user } }) => { if (user) setP((await db.from("profiles").select("*").eq("id", user.id).single()).data); }); }, []);
  if (!p) return <main className="p-8 text-mute">Loading…</main>;
  const set = (k: string, v: any) => setP({ ...p, [k]: v });
  async function avatar(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 5e6) return setMsg("Choose an image under 5 MB.");
    const path = `${p.id}/avatar-${Date.now()}`; const { error } = await db.storage.from("avatars").upload(path, file);
    if (error) return setMsg("Upload failed. Try again."); set("avatar_url", db.storage.from("avatars").getPublicUrl(path).data.publicUrl);
  }
  async function save(e: React.FormEvent) {
    e.preventDefault(); setMsg(""); if (p.website && !/^https?:\/\//.test(p.website)) return setMsg("Website must start with http:// or https://");
    setBusy(true); const { error } = await db.from("profiles").update({ full_name: p.full_name, bio: p.bio, website: p.website || null, avatar_url: p.avatar_url, is_private: p.is_private }).eq("id", p.id); setBusy(false);
    if (error) return setMsg("Couldn't save changes."); r.push(`/u/${p.username}`); r.refresh();
  }
  return <main className="mx-auto max-w-md space-y-4 p-6"><h1 className="font-display text-3xl font-extrabold">Edit profile</h1>
    <form onSubmit={save} className="space-y-3">
      <label className="flex items-center gap-4"><span className="h-20 w-20 overflow-hidden rounded-full border-2 border-glow bg-line">{p.avatar_url && <img src={p.avatar_url} alt="" className="h-full w-full object-cover" />}</span>
        <span className="btn-ghost">Change photo</span><input type="file" accept="image/*" hidden onChange={avatar} /></label>
      <input className="field" placeholder="Full name" value={p.full_name ?? ""} onChange={e => set("full_name", e.target.value)} />
      <textarea className="field" placeholder="Bio" maxLength={150} rows={3} value={p.bio ?? ""} onChange={e => set("bio", e.target.value)} />
      <input className="field" placeholder="Website" value={p.website ?? ""} onChange={e => set("website", e.target.value)} />
      <label className="flex items-center justify-between rounded-xl2 border border-line bg-surface px-4 py-3 text-sm">Private account<input type="checkbox" checked={p.is_private} onChange={e => set("is_private", e.target.checked)} className="h-5 w-5 accent-[#FFB020]" /></label>
      {msg && <p role="alert" className="text-sm text-red-500">{msg}</p>}<button className="btn-glow w-full" disabled={busy}>{busy ? "Saving…" : "Save changes"}</button></form>
    {p.role === "admin" && <Link href="/admin" className="btn-ghost w-full">Admin dashboard</Link>}
    <button className="btn-ghost w-full" onClick={async () => { await db.auth.signOut(); r.replace("/welcome"); r.refresh(); }}>Log out</button></main>;
}
