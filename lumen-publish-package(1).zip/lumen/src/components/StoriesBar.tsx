"use client";
import { useEffect, useState } from "react"; import { useRouter } from "next/navigation"; import { Plus, X } from "lucide-react"; import { supabase } from "@/lib/supabase/client";
type G = { id: string; username: string; avatar_url: string | null; items: { id: string; kind: string; media_url: string }[] };
export default function StoriesBar({ me, groups }: { me: string; groups: G[] }) {
  const r = useRouter(); const [open, setOpen] = useState<{ g: number; i: number } | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  async function add(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]; if (!f) return; if (f.size > 50e6) return setErr("Stories must be under 50 MB."); setBusy(true); setErr("");
    const db = supabase(); const path = `${me}/story-${Date.now()}`; const up = await db.storage.from("media").upload(path, f);
    const ins = up.error ? up : await db.from("stories").insert({ author_id: me, kind: f.type.startsWith("video") ? "video" : "photo", media_url: db.storage.from("media").getPublicUrl(path).data.publicUrl });
    setBusy(false); if (ins.error) setErr("Couldn't post your story."); else r.refresh();
  }
  const cur = open ? groups[open.g].items[open.i] : null;
  const next = () => setOpen(o => { if (!o) return o; const g = groups[o.g]; if (o.i + 1 < g.items.length) return { g: o.g, i: o.i + 1 }; return o.g + 1 < groups.length ? { g: o.g + 1, i: 0 } : null; });
  const prev = () => setOpen(o => o && o.i > 0 ? { g: o.g, i: o.i - 1 } : o);
  useEffect(() => { if (!cur || cur.kind === "video") return; const t = setTimeout(next, 5000); return () => clearTimeout(t); }, [open]);
  return <>
    <ul className="flex gap-4 overflow-x-auto px-4 py-4">
      <li className="shrink-0 text-center"><label className="grid h-16 w-16 cursor-pointer place-items-center rounded-full border-2 border-dashed border-line text-mute"><Plus />{busy ? "…" : null}<input type="file" accept="image/*,video/*" hidden onChange={add} /></label><span className="text-xs">Your story</span></li>
      {groups.map((g, n) => <li key={g.id} className="shrink-0 text-center"><button onClick={() => setOpen({ g: n, i: 0 })} aria-label={`${g.username}'s story`} className="h-16 w-16 rounded-full bg-glow p-[3px]">
        <span className="block h-full w-full overflow-hidden rounded-full border-2 border-bg bg-line">{g.avatar_url && <img src={g.avatar_url} alt="" className="h-full w-full object-cover" />}</span></button>
        <span className="block max-w-16 truncate text-xs">{g.username}</span></li>)}</ul>
    {err && <p role="alert" className="px-4 text-xs text-red-500">{err}</p>}
    {open && cur && <div className="fixed inset-0 z-50 bg-black" role="dialog" aria-label="Story">
      {cur.kind === "video" ? <video key={cur.id} src={cur.media_url} autoPlay playsInline onEnded={next} className="h-full w-full object-contain" /> : <img key={cur.id} src={cur.media_url} alt="" className="h-full w-full object-contain" />}
      <button className="absolute inset-y-0 left-0 w-1/3" onClick={prev} aria-label="Previous" /><button className="absolute inset-y-0 right-0 w-2/3" onClick={next} aria-label="Next" />
      <p className="absolute left-4 top-6 text-sm font-semibold text-white">{groups[open.g].username}</p>
      <button onClick={() => setOpen(null)} aria-label="Close" className="absolute right-4 top-5 text-white"><X /></button></div>}</>;
}
