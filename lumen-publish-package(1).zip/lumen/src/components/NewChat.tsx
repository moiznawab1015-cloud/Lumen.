"use client";
import { useState } from "react"; import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
export default function NewChat() {
  const r = useRouter(); const [u, setU] = useState(""); const [err, setErr] = useState("");
  async function go(e: React.FormEvent) { e.preventDefault(); setErr(""); const db = supabase();
    const { data: p } = await db.from("profiles").select("id").eq("username", u.trim().toLowerCase().replace(/^@/, "")).maybeSingle(); if (!p) return setErr("No account with that username.");
    const { data, error } = await db.rpc("start_conversation", { other: p.id }); if (error) return setErr("You can't message this account."); r.push(`/messages/${data}`); }
  return <form onSubmit={go} className="flex gap-2 px-4 pb-3"><input className="field" placeholder="Message someone by username" value={u} onChange={e => setU(e.target.value)} aria-label="Username" /><button className="btn-glow">Chat</button>{err && <p role="alert" className="sr-only">{err}</p>}</form>;
}
