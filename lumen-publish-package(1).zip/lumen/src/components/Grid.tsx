import Link from "next/link"; import { Clapperboard } from "lucide-react";
export default function Grid({ items }: { items: any[] }) {
  return <ul className="grid grid-cols-3 gap-0.5">{items.map(i => <li key={i.id} className="relative aspect-square bg-line"><Link href={`/p/${i.id}`}>
    <img src={i.thumb_url ?? i.media_url} alt="" loading="lazy" className="h-full w-full object-cover" />{i.is_reel && <Clapperboard size={16} className="absolute right-1.5 top-1.5 text-white drop-shadow" />}</Link></li>)}</ul>;
}
