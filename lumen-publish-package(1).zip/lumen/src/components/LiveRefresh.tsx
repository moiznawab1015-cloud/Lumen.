"use client";
import { useEffect } from "react"; import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
export default function LiveRefresh({ me }: { me: string }) {
  const r = useRouter();
  useEffect(() => { const db = supabase(); const ch = db.channel(`n-${me}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications", filter: `recipient_id=eq.${me}` }, () => r.refresh()).subscribe(); return () => { db.removeChannel(ch); }; }, [me]);
  return null;
}
