"use client";
import { useCallback, useEffect, useState } from "react"; import { supabase } from "@/lib/supabase/client"; import { ago } from "@/lib/time";
export default function CommentThread({ postId, me }: { postId: string; me: string }) {
  const db = supabase(); const [rows, setRows] = useState<any[] | null>(null); const [text, setText] = useState(""); const [reply, setReply] = useState<any>(null); const [err, setErr] = useState("");
  const load = useCallback(async () => { const { data } = await db.from("comments").select("*, profiles(username)").eq("post_id", postId).order("created_at"); setRows(data ?? []); }, [postId]);
  useEffect(() => { load(); const ch = db.channel(`c-${postId}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "comments", filter: `post_id=eq.${postId}` }, load).subscribe(); return () => { db.removeChannel(ch); }; }, [load]);
  async function send(e: React.FormEvent) { e.preventDefault(); const body = text.trim(); if (!body) return; if (body.length > 500) return setErr("Comments are limited to 500 characters.");
    setErr(""); const { error } = await db.from("comments").insert({ post_id: postId, author_id: me, body, parent_id: reply?.id ?? null });
    if (error) return setErr("Couldn't post your comment."); setText(""); setReply(null); load(); }
  async function del(id: string) { await db.from("comments").delete().eq("id", id); load(); }
  if (!rows) return <p className="p-4 text-mute">Loading comments…</p>;
  const item = (c: any, child = false) => <li key={c.id} className={child ? "ml-8" : ""}><p className="text-sm"><span className="font-semibold">{c.profiles.username}</span> {c.body}</p>
    <p className="text-xs text-mute">{ago(c.created_at)} {!child && <button onClick={() => { setReply(c); setText(`@${c.profiles.username} `); }} className="ml-2 font-semibold">Reply</button>}
      {c.author_id === me && <button onClick={() => del(c.id)} className="ml-2">Delete</button>}</p></li>;
  const top = rows.filter(c => !c.parent_id);
  return <section className="px-4 pb-24"><ul className="space-y-3">{top.map(c => <div key={c.id} className="space-y-3">{item(c)}{rows.filter(r => r.parent_id === c.id).map(r => item(r, true))}</div>)}
    {top.length === 0 && <p className="py-6 text-center text-mute">No comments yet. Start the conversation.</p>}</ul>
    <form onSubmit={send} className="fixed inset-x-0 bottom-16 mx-auto flex max-w-md gap-2 border-t border-line bg-bg p-3">
      <input className="field" value={text} onChange={e => setText(e.target.value)} placeholder={reply ? `Replying to ${reply.profiles.username}` : "Add a comment"} aria-label="Comment" />
      <button className="btn-glow">Post</button></form>{err && <p role="alert" className="text-xs text-red-500">{err}</p>}</section>;
}
