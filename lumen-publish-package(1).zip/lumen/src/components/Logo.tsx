export default function Logo({ size = 40 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 48 48" aria-label="Lumen" role="img">
    <rect width="48" height="48" rx="15" fill="#191916"/>
    <path d="M24 9.5v5.2M24 33.3v5.2M9.5 24h5.2M33.3 24h5.2M13.75 13.75l3.7 3.7M30.55 30.55l3.7 3.7M34.25 13.75l-3.7 3.7M17.45 30.55l-3.7 3.7" stroke="#D2B47C" strokeWidth="2.1" strokeLinecap="round"/>
    <circle cx="24" cy="24" r="7.2" fill="none" stroke="#F4F0E8" strokeWidth="2.5"/>
    <circle cx="24" cy="24" r="2.3" fill="#D2B47C"/>
  </svg>;
}
