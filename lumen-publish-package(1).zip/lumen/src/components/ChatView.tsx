"use client";
import Link from "next/link"; import { useCallback, useEffect, useRef, useState } from "react"; import { ImagePlus } from "lucide-react"; import { supabase } from "@/lib/supabase/client";
const hm = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
export default function ChatView({ me, convId, initial }: { me: string; convId: string; initial: any[] }) {
  const db = supabase(); const [msgs, setMsgs] = useState(initial); const [text, setText] = useState(""); const [err, setErr] = useState(""); const end = useRef<HTMLDivElement>(null);
  const load = useCallback(async () => { const { data } = await db.from("messages").select("*, shared:posts(id,thumb_url,media_url,caption)").eq("conversation_id", convId).order("created_at"); if (data) setMsgs(data);
    db.from("conversation_members").update({ last_read_at: new Date().toISOString() }).match({ conversation_id: convId, user_id: me }).then(() => {}); }, [convId]);
  useEffect(() => { load(); const ch = db.channel(`chat-${convId}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${convId}` }, load).subscribe(); return () => { db.removeChannel(ch); }; }, [load]);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);
  async function send(e: React.FormEvent) { e.preventDefault(); const body = text.trim(); if (!body) return; if (body.length > 2000) return setErr("Messages are limited to 2000 characters.");
    setErr(""); setText(""); const { error } = await db.from("messages").insert({ conversation_id: convId, sender_id: me, body }); if (error) { setErr("Couldn't send. Try again."); setText(body); } else load(); }
  async function img(e: React.ChangeEvent<HTMLInputElement>) { const f = e.target.files?.[0]; if (!f) return; if (!f.type.startsWith("image/") || f.size > 10e6) return setErr("Choose an image under 10 MB.");
    const path = `${me}/dm-${crypto.randomUUID()}`; const up = await db.storage.from("media").upload(path, f); if (up.error) return setErr("Couldn't upload that photo.");
    await db.from("messages").insert({ conversation_id: convId, sender_id: me, image_url: db.storage.from("media").getPublicUrl(path).data.publicUrl }); load(); }
  return <><ul className="space-y-2 px-4 pb-40 pt-4">{msgs.map(m => { const mine = m.sender_id === me; return <li key={m.id} className={`flex ${mine ? "justify-end" : ""}`}>
    <div className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-glow text-glow-ink" : "bg-surface border border-line"}`}>
      {m.image_url && <img src={m.image_url} alt="Photo" className="mb-1 rounded-xl" />}
      {m.shared_post_id && (m.shared ? <Link href={`/p/${m.shared.id}`} className="block"><img src={m.shared.thumb_url ?? m.shared.media_url} alt="" className="mb-1 aspect-square w-40 rounded-xl object-cover" /><span className="text-xs underline">{m.shared.caption?.slice(0, 40) || "View post"}</span></Link> : <span className="italic opacity-70">Post unavailable</span>)}
      {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}<time className="mt-0.5 block text-[10px] opacity-60">{hm(m.created_at)}</time></div></li>; })}
    {msgs.length === 0 && <li className="py-10 text-center text-mute">Say hi 👋</li>}<div ref={end} /></ul>
    <form onSubmit={send} className="fixed inset-x-0 bottom-16 mx-auto flex max-w-md items-center gap-2 border-t border-line bg-bg p-3">
      <label className="cursor-pointer text-mute" aria-label="Send photo"><ImagePlus /><input type="file" accept="image/*" hidden onChange={img} /></label>
      <input className="field" value={text} onChange={e => setText(e.target.value)} placeholder="Message" aria-label="Message" /><button className="btn-glow">Send</button></form>
    {err && <p role="alert" className="fixed inset-x-0 bottom-32 mx-auto max-w-md px-4 text-xs text-red-500">{err}</p>}</>;
}
