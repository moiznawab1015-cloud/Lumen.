"use client";
import { useState } from "react"; import { supabase } from "@/lib/supabase/client";
type S = "none" | "pending" | "accepted";
export default function FollowButton({ me, target, initial, isPrivate }: { me: string; target: string; initial: S; isPrivate: boolean }) {
  const [s, setS] = useState<S>(initial); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  async function toggle() {
    setBusy(true); setErr(""); const db = supabase();
    const { error } = s === "none" ? await db.from("follows").insert({ follower_id: me, followee_id: target })
      : await db.from("follows").delete().match({ follower_id: me, followee_id: target });
    if (error) setErr("Couldn't update. Try again."); else setS(s === "none" ? (isPrivate ? "pending" : "accepted") : "none");
    setBusy(false);
  }
  return <div><button onClick={toggle} disabled={busy} className={s === "none" ? "btn-glow" : "btn-ghost"}>
    {s === "none" ? "Follow" : s === "pending" ? "Requested" : "Following"}</button>{err && <p role="alert" className="mt-1 text-xs text-red-500">{err}</p>}</div>;
}
