"use client";
import { useEffect, useState } from "react"; import { supabase } from "@/lib/supabase/client"; import { loadConversations } from "@/lib/dm";
export default function ShareSheet({ me, postId, onClose }: { me: string; postId: string; onClose: () => void }) {
  const db = supabase(); const [convs, setConvs] = useState<any[] | null>(null); const [note, setNote] = useState("");
  useEffect(() => { loadConversations(db, me).then(setConvs); }, []);
  async function send(id: string, name: string) { const { error } = await db.from("messages").insert({ conversation_id: id, sender_id: me, shared_post_id: postId }); setNote(error ? "Couldn't send. Try again." : `Sent to ${name}`); }
  async function link() { const url = `${location.origin}/p/${postId}`; try { if (navigator.share) await navigator.share({ url }); else { await navigator.clipboard.writeText(url); setNote("Link copied"); } } catch {} }
  return <div role="dialog" aria-label="Share" className="fixed inset-0 z-50 flex items-end bg-black/50" onClick={onClose}>
    <div onClick={e => e.stopPropagation()} className="mx-auto max-h-[70dvh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-bg p-5 pb-8 text-ink">
      <h2 className="font-display text-xl font-extrabold">Share</h2>
      <button className="btn-ghost mt-3 w-full" onClick={link}>Copy or share link</button>
      <p className="mb-2 mt-4 text-sm font-semibold">Send in a message</p>
      {!convs ? <p className="text-sm text-mute">Loading…</p> : convs.length === 0 ? <p className="text-sm text-mute">No conversations yet. Start one from someone’s profile.</p>
        : <ul>{convs.map(c => <li key={c.id}><button onClick={() => send(c.id, c.other.username)} className="flex w-full items-center gap-3 py-2 text-left"><span className="h-10 w-10 overflow-hidden rounded-full bg-line">{c.other.avatar_url && <img src={c.other.avatar_url} alt="" className="h-full w-full object-cover" />}</span><span className="flex-1 text-sm font-semibold">{c.other.username}</span><span className="text-sm text-glow">Send</span></button></li>)}</ul>}
      {note && <p role="status" className="mt-3 text-sm text-mute">{note}</p>}</div></div>;
}
