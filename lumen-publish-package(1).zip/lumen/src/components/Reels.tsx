"use client";
import { useEffect, useRef, useState } from "react"; import Link from "next/link"; import { Heart, MessageCircle, Send, Bookmark, Volume2, VolumeX, Play, Eye, Plus } from "lucide-react";
import { supabase } from "@/lib/supabase/client"; import FollowButton from "./FollowButton"; import ShareSheet from "./ShareSheet";
function Reel({ me, it, muted, live }: { me: string; it: any; muted: boolean; live: any }) {
  const db = supabase(); const p = it.post; const v = useRef<HTMLVideoElement>(null); const counted = useRef(false);
  const [paused, setPaused] = useState(false); const [liked, setLiked] = useState(it.liked); const [saved, setSaved] = useState(it.saved); const [likes, setLikes] = useState<number>(it.stats.like_count); const [views, setViews] = useState<number>(it.stats.view_count); const [share, setShare] = useState(false);
  useEffect(() => { if (live) { setLikes(live.like_count); setViews(live.view_count); } }, [live?.like_count, live?.view_count]);
  useEffect(() => { const el = v.current!; const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.play().then(() => setPaused(false)).catch(() => {}); } else { el.pause(); el.currentTime = 0; } }, { threshold: 0.7 }); io.observe(el); return () => io.disconnect(); }, []);
  function played() { if (counted.current) return; counted.current = true; setViews(n => n + 1); db.from("post_views").insert({ post_id: p.id, viewer_id: me }).then(() => {}); }
  async function like() { const n = !liked; setLiked(n); setLikes(c => c + (n ? 1 : -1)); const { error } = n ? await db.from("likes").insert({ user_id: me, post_id: p.id }) : await db.from("likes").delete().match({ user_id: me, post_id: p.id }); if (error) { setLiked(!n); setLikes(c => c + (n ? -1 : 1)); } }
  async function save() { const n = !saved; setSaved(n); const { error } = n ? await db.from("saves").insert({ user_id: me, post_id: p.id }) : await db.from("saves").delete().match({ user_id: me, post_id: p.id }); if (error) setSaved(!n); }
  const rail = "flex flex-col items-center gap-1 text-xs text-white drop-shadow";
  return <section className="relative h-full snap-start snap-always bg-black">
    <video ref={v} src={p.media_url} poster={p.thumb_url ?? undefined} loop playsInline muted={muted} preload="metadata" onPlay={played} onClick={() => { const el = v.current!; if (el.paused) { el.play(); setPaused(false); } else { el.pause(); setPaused(true); } }} className="h-full w-full object-cover" />
    {paused && <Play size={64} className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white/80" />}
    <div className="absolute bottom-4 right-3 flex flex-col items-center gap-5">
      <button className={rail} onClick={like} aria-pressed={liked} aria-label="Like"><Heart size={28} className={liked ? "fill-glow text-glow" : ""} />{likes}</button>
      <Link className={rail} href={`/p/${p.id}`} aria-label="Comments"><MessageCircle size={28} />{live?.comment_count ?? it.stats.comment_count}</Link>
      <button className={rail} onClick={() => setShare(true)} aria-label="Share"><Send size={26} /></button>
      <button className={rail} onClick={save} aria-pressed={saved} aria-label="Save"><Bookmark size={26} className={saved ? "fill-white" : ""} /></button>
      <span className={rail}><Eye size={22} />{views}</span></div>
    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-4 pr-20 text-white">
      <div className="flex items-center gap-3"><Link href={`/u/${p.profiles.username}`} className="font-semibold">@{p.profiles.username}</Link>{p.author_id !== me && <FollowButton me={me} target={p.author_id} initial={it.following} isPrivate={false} />}</div>
      {p.caption && <p className="mt-2 line-clamp-2 text-sm">{p.caption}</p>}</div>
    {share && <ShareSheet me={me} postId={p.id} onClose={() => setShare(false)} />}</section>;
}
export default function Reels({ me, items }: { me: string; items: any[] }) {
  const [muted, setMuted] = useState(true); const [live, setLive] = useState<Record<string, any>>({});
  useEffect(() => { const db = supabase(); const ids = items.map(i => i.post.id); const t = setInterval(async () => { const { data } = await db.from("post_stats").select("*").in("post_id", ids); if (data) setLive(Object.fromEntries(data.map((s: any) => [s.post_id, s]))); }, 10000); return () => clearInterval(t); }, [items]);
  return <main className="fixed inset-x-0 top-0 bottom-16 z-30 mx-auto max-w-md snap-y snap-mandatory overflow-y-scroll bg-black">
    <div className="pointer-events-none fixed inset-x-0 top-0 z-40 mx-auto flex max-w-md justify-between p-4"><Link href="/studio" aria-label="Create Reel" className="pointer-events-auto grid h-10 w-10 place-items-center rounded-full bg-black/40 text-white"><Plus /></Link>
      <button onClick={() => setMuted(m => !m)} aria-label={muted ? "Unmute" : "Mute"} className="pointer-events-auto grid h-10 w-10 place-items-center rounded-full bg-black/40 text-white">{muted ? <VolumeX size={20} /> : <Volume2 size={20} />}</button></div>
    <div className="h-full">{items.map(it => <div key={it.post.id} className="h-full"><Reel me={me} it={it} muted={muted} live={live[it.post.id]} /></div>)}</div></main>;
}
