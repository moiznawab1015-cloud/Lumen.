"use client";
import Link from "next/link"; import { usePathname } from "next/navigation";
import { Home, Compass, Plus, Clapperboard, User } from "lucide-react";
export default function BottomNav({ username }: { username: string }) {
  const p = usePathname();
  const items = [{ href:"/", I:Home, l:"Home" },{ href:"/explore", I:Compass, l:"Explore" },{ href:"/create", I:Plus, l:"Create", cta:true },
    { href:"/reels", I:Clapperboard, l:"Reels" },{ href:`/u/${username}`, I:User, l:"Profile" }];
  return <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/90 backdrop-blur" style={{ paddingBottom:"env(safe-area-inset-bottom)" }}>
    <ul className="mx-auto flex max-w-md items-center justify-around py-2">{items.map(({ href, I, l, cta }) =>
      <li key={l}><Link href={href} aria-label={l} className={cta ? "grid h-11 w-14 place-items-center rounded-2xl bg-glow text-glow-ink" : `grid h-11 w-11 place-items-center rounded-xl ${p === href ? "text-ink" : "text-mute"}`}>
        <I size={cta ? 24 : 22} strokeWidth={p === href ? 2.5 : 1.8} /></Link></li>)}</ul></nav>;
}
