"use client";
import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
export default function RequestActions({ follower, me }: { follower: string; me: string }) {
  const r = useRouter(); const db = supabase();
  const act = async (ok: boolean) => { ok ? await db.from("follows").update({ status: "accepted" }).match({ follower_id: follower, followee_id: me }) : await db.from("follows").delete().match({ follower_id: follower, followee_id: me }); r.refresh(); };
  return <span className="ml-auto flex gap-2"><button className="btn-glow !px-3 !py-1.5" onClick={() => act(true)}>Accept</button><button className="btn-ghost !px-3 !py-1.5" onClick={() => act(false)}>Decline</button></span>;
}
