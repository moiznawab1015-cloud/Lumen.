"use client";
import Link from "next/link"; import { useEffect, useState } from "react"; import { Bell, Send } from "lucide-react"; import { supabase } from "@/lib/supabase/client";
export default function HeaderActions({ me, notifs, dms }: { me: string; notifs: number; dms: number }) {
  const [n, setN] = useState(notifs), [d, setD] = useState(dms);
  useEffect(() => { const db = supabase();
    const ch = db.channel(`hdr-${me}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications", filter: `recipient_id=eq.${me}` }, () => setN(x => x + 1))
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (p: any) => { if (p.new.sender_id !== me) setD(x => x + 1); }).subscribe();
    return () => { db.removeChannel(ch); }; }, [me]);
  const badge = (c: number) => c > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-glow px-1 text-[10px] font-bold text-glow-ink">{c > 9 ? "9+" : c}</span>;
  return <div className="ml-auto flex gap-4"><Link href="/notifications" aria-label="Notifications" className="relative"><Bell />{badge(n)}</Link><Link href="/messages" aria-label="Messages" className="relative"><Send />{badge(d)}</Link></div>;
}
