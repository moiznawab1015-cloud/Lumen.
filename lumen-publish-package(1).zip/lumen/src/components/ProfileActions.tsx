"use client";
import { useState } from "react"; import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
export default function ProfileActions({ me, target, blocked: b0 }: { me: string; target: string; username: string; blocked: boolean }) {
  const r = useRouter(); const db = supabase(); const [blocked, setBlocked] = useState(b0); const [note, setNote] = useState("");
  async function message() { const { data, error } = await db.rpc("start_conversation", { other: target }); if (error) return setNote("You can't message this account."); r.push(`/messages/${data}`); }
  async function block() {
    if (!blocked && !confirm("Block this account? They won't be able to see your posts.")) return;
    if (blocked) { await db.from("blocks").delete().match({ blocker_id: me, blocked_id: target }); setBlocked(false); }
    else { await db.from("blocks").insert({ blocker_id: me, blocked_id: target }); await db.from("follows").delete().match({ follower_id: me, followee_id: target }); await db.from("follows").delete().match({ follower_id: target, followee_id: me }); setBlocked(true); }
    r.refresh(); }
  async function report() { const reason = prompt("Why are you reporting this account?"); if (!reason?.trim()) return; const { error } = await db.from("reports").insert({ reporter_id: me, reported_user_id: target, reason: reason.trim() }); setNote(error ? "Couldn't send report." : "Report sent. Thank you."); }
  return <div className="mt-3 flex flex-wrap gap-2">{!blocked && <button className="btn-ghost flex-1" onClick={message}>Message</button>}
    <button className="btn-ghost flex-1" onClick={block}>{blocked ? "Unblock" : "Block"}</button><button className="btn-ghost flex-1" onClick={report}>Report</button>{note && <p role="status" className="w-full text-xs text-mute">{note}</p>}</div>;
}
