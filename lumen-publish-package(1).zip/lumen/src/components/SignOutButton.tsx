"use client";
import { useRouter } from "next/navigation"; import { supabase } from "@/lib/supabase/client";
export default function SignOutButton() { const r = useRouter(); return <button className="btn-ghost" onClick={async () => { await supabase().auth.signOut(); r.replace("/welcome"); r.refresh(); }}>Log out</button>; }
