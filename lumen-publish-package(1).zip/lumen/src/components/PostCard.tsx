"use client";
import Link from "next/link"; import { useEffect, useRef, useState } from "react";
import { Heart, MessageCircle, Send, Bookmark, Flag, Eye } from "lucide-react";
import { supabase } from "@/lib/supabase/client"; import { ago } from "@/lib/time"; import ShareSheet from "./ShareSheet";
const linkify = (t: string) => t.split(/([@#][\w.]+)/g).map((s, i) => s[0] === "@" ? <Link key={i} href={`/u/${s.slice(1)}`} className="font-semibold text-glow">{s}</Link> : s[0] === "#" ? <span key={i} className="font-semibold text-glow">{s}</span> : s);
export default function PostCard({ me, post, stats, liked: l0, saved: s0 }: { me: string; post: any; stats: any; liked: boolean; saved: boolean }) {
  const db = supabase(); const [liked, setLiked] = useState(l0); const [saved, setSaved] = useState(s0); const [likes, setLikes] = useState<number>(stats.like_count);
  const [sheet, setSheet] = useState(false); const [pop, setPop] = useState(false); const [note, setNote] = useState(""); const last = useRef(0); const vid = useRef<HTMLVideoElement>(null); const counted = useRef(false);
  useEffect(() => { const v = vid.current; if (!v) return; const io = new IntersectionObserver(([e]) => e.isIntersecting ? v.play().catch(() => {}) : v.pause(), { threshold: 0.6 }); io.observe(v); return () => io.disconnect(); }, []);
  async function setLike(next: boolean) {
    if (next === liked) return; setLiked(next); setLikes(n => n + (next ? 1 : -1));
    const { error } = next ? await db.from("likes").insert({ user_id: me, post_id: post.id }) : await db.from("likes").delete().match({ user_id: me, post_id: post.id });
    if (error) { setLiked(!next); setLikes(n => n + (next ? -1 : 1)); setNote("Couldn't update like."); }
  }
  async function toggleSave() { const n = !saved; setSaved(n);
    const { error } = n ? await db.from("saves").insert({ user_id: me, post_id: post.id }) : await db.from("saves").delete().match({ user_id: me, post_id: post.id });
    if (error) setSaved(!n); else setNote(n ? "Saved" : "Removed from saved"); }
  async function share() { const url = `${location.origin}/p/${post.id}`; try { if (navigator.share) await navigator.share({ url }); else { await navigator.clipboard.writeText(url); setNote("Link copied"); } } catch {} }
  async function report() { const reason = prompt("Why are you reporting this post?"); if (!reason?.trim()) return;
    const { error } = await db.from("reports").insert({ reporter_id: me, post_id: post.id, reason: reason.trim() }); setNote(error ? "Couldn't send report." : "Report sent. Thank you."); }
  function tap() { const t = Date.now(); if (t - last.current < 300) { setLike(true); setPop(true); setTimeout(() => setPop(false), 700); } last.current = t; }
  function played() { if (counted.current) return; counted.current = true; db.from("post_views").insert({ post_id: post.id, viewer_id: me }).then(() => {}); }
  const a = post.profiles;
  return <article className="border-b border-line pb-4">
    <header className="flex items-center gap-3 px-4 py-3"><Link href={`/u/${a.username}`} className="flex items-center gap-3"><span className="h-9 w-9 overflow-hidden rounded-full bg-line">{a.avatar_url && <img src={a.avatar_url} alt="" className="h-full w-full object-cover" />}</span>
      <span className="text-sm font-semibold">{a.username}</span></Link><span className="text-xs text-mute">{ago(post.created_at)}</span>
      {post.author_id !== me && <button onClick={report} aria-label="Report post" className="ml-auto text-mute"><Flag size={18} /></button>}</header>
    <div className="relative select-none bg-line" onPointerUp={tap}>
      {post.kind === "video" ? <video ref={vid} src={post.media_url} poster={post.thumb_url ?? undefined} onPlay={played} muted loop playsInline controls className="max-h-[70dvh] w-full object-contain" />
        : <img src={post.media_url} alt={post.caption ?? ""} className="w-full" loading="lazy" draggable={false} />}
      {pop && <Heart size={96} className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 animate-ping fill-glow text-glow" />}</div>
    <div className="flex items-center gap-4 px-4 pt-3">
      <button onClick={() => setLike(!liked)} aria-label={liked ? "Unlike" : "Like"} aria-pressed={liked}><Heart className={liked ? "fill-glow text-glow" : ""} /></button>
      <Link href={`/p/${post.id}`} aria-label="Comments"><MessageCircle /></Link><button onClick={() => setSheet(true)} aria-label="Share"><Send /></button>
      <button onClick={toggleSave} aria-label={saved ? "Unsave" : "Save"} aria-pressed={saved} className="ml-auto"><Bookmark className={saved ? "fill-ink" : ""} /></button></div>
    <div className="px-4 pt-2 text-sm"><p className="font-semibold">{likes} {likes === 1 ? "like" : "likes"}{post.kind === "video" && <span className="ml-3 inline-flex items-center gap-1 font-normal text-mute"><Eye size={14} />{stats.view_count}</span>}</p>
      {post.caption && <p className="mt-1"><span className="font-semibold">{a.username}</span> {linkify(post.caption)}</p>}
      {stats.comment_count > 0 && <Link href={`/p/${post.id}`} className="mt-1 block text-mute">View all {stats.comment_count} comments</Link>}
      {note && <p role="status" className="mt-1 text-xs text-mute">{note}</p>}</div>{sheet && <ShareSheet me={me} postId={post.id} onClose={() => setSheet(false)} />}</article>;
}
