import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req });
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { cookies: {
    getAll: () => req.cookies.getAll(),
    setAll: (l) => { l.forEach(({name,value}) => req.cookies.set(name,value)); res = NextResponse.next({ request: req });
      l.forEach(({name,value,options}) => res.cookies.set(name,value,options)); } } });
  const { data:{ user } } = await sb.auth.getUser();
  const onWelcome = req.nextUrl.pathname.startsWith("/welcome");
  if (!user && !onWelcome) return NextResponse.redirect(new URL("/welcome", req.url));
  if (user && onWelcome) return NextResponse.redirect(new URL("/", req.url));
  return res;
}
export const config = { matcher: ["/((?!_next|favicon.ico|.*\\..*).*)"] };
